# # import matplotlib.pyplot as plt
# # import display as qt
# from .display import *
# from .pint_sympy import unitregistry as u

# # import the pipe command
# # import .pipe_command as pc

# # sympy printing settings
# import sympy as sp
# mul_symbol = r"\,"
# sp.init_printing(mul_symbol=mul_symbol, order="none")
# platex = lambda x: latex(x, mode="inline", mul_symbol=mul_symbol)

print("ciao")

from dataframe import *
from display import *
